<?php

/**
 * @file
 * Test version of example.sites.php from drupal/core.
 */
