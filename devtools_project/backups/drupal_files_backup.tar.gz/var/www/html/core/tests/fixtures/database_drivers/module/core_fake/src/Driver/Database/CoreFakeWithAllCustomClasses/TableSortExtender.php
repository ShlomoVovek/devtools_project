<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\TableSortExtender as QueryTableSortExtender;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Query\TableSortExtender.
 */
class TableSortExtender extends QueryTableSortExtender {

}
