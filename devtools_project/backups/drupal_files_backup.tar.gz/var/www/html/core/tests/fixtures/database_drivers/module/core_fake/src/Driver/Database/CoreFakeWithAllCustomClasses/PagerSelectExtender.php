<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\PagerSelectExtender as QueryPagerSelectExtender;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Query\PagerSelectExtender.
 */
class PagerSelectExtender extends QueryPagerSelectExtender {

}
