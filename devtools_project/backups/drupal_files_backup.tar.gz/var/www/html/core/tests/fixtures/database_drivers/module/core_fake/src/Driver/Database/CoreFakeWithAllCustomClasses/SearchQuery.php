<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\search\SearchQuery as CoreSearchQuery;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\search\SearchQuery.
 */
class SearchQuery extends CoreSearchQuery {

}
