<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Transaction as DatabaseTransaction;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Transaction.
 */
class Transaction extends DatabaseTransaction {

}
