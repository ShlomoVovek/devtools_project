<?php

namespace Drupal\Driver\Database\CoreFake;

use Drupal\Core\Database\Driver\CoreFake\Connection as CoreFakeConnection;

class Connection extends CoreFakeConnection {}
