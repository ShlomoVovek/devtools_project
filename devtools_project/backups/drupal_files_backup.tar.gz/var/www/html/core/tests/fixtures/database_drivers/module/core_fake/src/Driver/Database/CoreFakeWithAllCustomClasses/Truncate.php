<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Truncate as QueryTruncate;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Truncate.
 */
class Truncate extends QueryTruncate {

}
