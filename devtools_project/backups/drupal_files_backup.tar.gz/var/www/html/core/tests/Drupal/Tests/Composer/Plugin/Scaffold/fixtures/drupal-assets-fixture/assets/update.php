<?php

/**
 * @file
 * Test version of update.php from drupal/core.
 */
