<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Condition as QueryCondition;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Condition.
 */
class Condition extends QueryCondition {

}
