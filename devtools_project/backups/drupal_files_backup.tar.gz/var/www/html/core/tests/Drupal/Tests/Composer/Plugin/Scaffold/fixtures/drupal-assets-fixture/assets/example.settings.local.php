<?php

/**
 * @file
 * Test version of example.settings.local.php from drupal/core.
 */
