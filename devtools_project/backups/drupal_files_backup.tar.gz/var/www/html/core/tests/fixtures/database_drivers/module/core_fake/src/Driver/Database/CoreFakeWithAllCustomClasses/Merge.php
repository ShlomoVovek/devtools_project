<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Merge as QueryMerge;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Merge.
 */
class Merge extends QueryMerge {

}
