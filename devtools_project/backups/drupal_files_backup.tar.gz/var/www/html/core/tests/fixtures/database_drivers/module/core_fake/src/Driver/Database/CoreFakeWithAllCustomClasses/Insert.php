<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Insert as QueryInsert;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Insert.
 */
class Insert extends QueryInsert {

}
